class ZippedKategori:
    def __init__(self, path):
        self.path = path
        self.zipped_kategori = self.parse_zipped_kategori()

    def parse_zipped_kategori(self):
        # code to parse the kategori data and return the zipped data
        pass